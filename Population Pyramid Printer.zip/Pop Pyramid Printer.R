#install.packages("pacman")
pacman::p_load(dplyr, openxlsx)


#####################################################################
### Edit these files to personalise for your own special dataset  ###
#####################################################################
### Create a flat population file, with a columns Year, Age, Males, Females, or other columns that you wish to read in for 'gender' (Immigrants?). 
### All years must have the same number of ages, 
### You must have annual data by single year of age 

Options  <- read.xlsx("c:/users/TCV/OneDrive - Treasury/documents/data visualisation/2025/DataHoldings.xlsx", sheet = "Index")
head(Options,30)

Selection <- "Italy"
gender =   "Both"  # Males, Females, Total, Both

choice <- Options %>%
  filter(Sheet == Selection)   

head(choice)

Pop  <- read.xlsx("c:/users/TCV/OneDrive - Treasury/documents/data visualisation/2025/DataHoldings.xlsx", sheet = choice$Sheet)
head(Pop)
Pop <- Pop %>%
  rename(Males = Male,
         Females = Female) %>%
  mutate (Age = (as.numeric(Age) - as.numeric(choice$MinAge))) %>%
  filter (Age > -1) %>%            
  mutate (Age = as.character(Age))

head(Pop)
choice$Sheet
filename  <- paste0("c:/users/TCV/OneDrive - Treasury/documents/data visualisation/2025/",choice$Sheet,gender,".stl")
filename
Pop$Males <- case_when(gender == "Males" ~ Pop$Males,
                       gender == "Females" ~ 0,
                       gender == "Total" ~ 0, 
                       gender == "Both" ~ Pop$Males    )

Pop$Females <- case_when(gender == "Males" ~ 0,
                       gender == "Females" ~ Pop$Females,
                       gender == "Total" ~ 0 ,
                       gender == "Both" ~ Pop$Females)  

###########
## Clean ##
## ===== ##
###########

Pop$Year <- abs(as.numeric(Pop$Year))
Pop$Age  <- abs(as.numeric(Pop$Age))
Pop <- na.omit(Pop)

Min_age = as.numeric(min(Pop$Age)  )
Max_age = as.numeric(max(Pop$Age)  )
Min_year = as.numeric(min(Pop$Year))
Max_year = as.numeric(max(Pop$Year))
No_years <- as.numeric(Max_year - Min_year)
Max_male <- as.numeric(min(-Pop$Males))       
Max_female <- as.numeric(max(Pop$Females))

endfile <- subset (Pop, Age == Max_age)
endfile$Age <- Max_age + 1
endfile$Males <- 0
endfile$Females <- 0
Pop <- rbind(Pop, endfile)
Pop$Females <- Pop$Females / choice$Scale  ##
Pop$Males   <- Pop$Males   / choice$Scale
Max_age = max(Pop$Age)    ## recalculate max_age, as we've added an age one more than oldest age
max(Pop$Males)
max(Pop$Females)


Pop$Row <- (Pop$Year - Min_year) * (Max_age + 1) + Pop$Age + 1
MaxRow <- max(Pop$Row - Max_age - 1)                                    #### Because data has to go to year + 1, end build at at T-1 
Pop <- Pop[order(Pop$Row),]

## X = population
## y = year
## z = age
size <- MaxRow

fp <- file(filename, open="w")
if (!fp) { stop("There was a problem opening the file for writing") }

write('solid pyramid', file=fp)
### Female side 
for (i in 1:size) { 
j <- as.numeric(i)
x <- as.numeric(Pop$Females[i])
y <- as.numeric(Pop$Year[i])
z <- as.numeric(Pop$Age[i])
xy <- as.numeric(Pop$Females [i+Max_age +1])  ## pop at age i   , year i+1
xyz <- ifelse( z >= Max_age-1,0,   as.numeric(Pop$Females[i+Max_age+2]))   ## pop at age i+1 , year i+1
xz  <- ifelse( z >= Max_age-1, 0, as.numeric(Pop$Females[i+1]) )          ## pop at age i+1 , year i

## for facet, pointing outward, calculate centre of triangle

cx <- max(x, xy, xyz)*1.001
cxx <- max(x, xz, xyz)*1.001
cy <- as.numeric(Pop$Year[i] + .2)  
cz <- as.numeric(Pop$Age[i]  + .2)  

## Triangle A
# write(i, file=fp)
write(sprintf('  facet normal %f %f %f', cx, y+.8, z+.2), file=fp)
  write('    outer loop', file=fp)
    write(sprintf('      vertex %f %f %f', x  , y  , z  ) , file=fp)
    write(sprintf('      vertex %f %f %f', xy , y+1, z  ) , file=fp)
    write(sprintf('      vertex %f %f %f', xyz, y+1, z+1) , file=fp)
  write('    endloop', file=fp)
write('  endfacet', file=fp)


## Triangle B
write(sprintf('  facet normal %f %f %f', cxx, y+.2, z+.8 ) , file=fp)
write('    outer loop', file=fp)
write(sprintf('      vertex %f %f %f', x  , y  , z  ) , file=fp)
write(sprintf('      vertex %f %f %f', xyz, y+1, z+1) , file=fp)
write(sprintf('      vertex %f %f %f', xz , y  , z+1) , file=fp)
write('    endloop', file=fp)
write('  endfacet', file=fp)

}




### Male side 
for (i in 1:size) { 
  j <- as.numeric(i)
  x <- -as.numeric(Pop$Males[i])
  y <- as.numeric(Pop$Year[i])
  z <- as.numeric(Pop$Age[i])
  xy <- -as.numeric(Pop$Males [i+Max_age +1])  ## pop at age i   , year i+1
  xyz <- ifelse( z >= Max_age-1,0,  -as.numeric(Pop$Males[i+Max_age+2]))   ## pop at age i+1 , year i+1
  xz  <- ifelse( z >= Max_age-1, 0, -as.numeric(Pop$Males[i+1]) )          ## pop at age i+1 , year i
  
  ## for facet, pointing outward, calculate centre of triangle
  
  cx <- max(x, xy, xyz)*1.001
  cxx <- max(x, xz, xyz)*1.001
  cy <- as.numeric(Pop$Year[i] + .2)  
  cz <- as.numeric(Pop$Age[i]  + .2)  
  
  ## Triangle A
  
  write(sprintf('  facet normal %f %f %f', cx, y+.8, z+.2), file=fp)
    write('    outer loop', file=fp)
      write(sprintf('      vertex %f %f %f', x  , y  , z  ) , file=fp)
      write(sprintf('      vertex %f %f %f', xyz, y+1, z+1) , file=fp)
      write(sprintf('      vertex %f %f %f', xy , y+1, z  ) , file=fp)
    write('    endloop', file=fp)
  write('  endfacet', file=fp)
  
  
  ## Triangle B
  write(sprintf('  facet normal %f %f %f', cxx, y+.2, z+.8 ) , file=fp)
    write('    outer loop', file=fp)
      write(sprintf('      vertex %f %f %f', x  , y  , z  ) , file=fp)
      write(sprintf('      vertex %f %f %f', xz , y  , z+1) , file=fp)
      write(sprintf('      vertex %f %f %f', xyz, y+1, z+1) , file=fp)
    write('    endloop', file=fp)
  write('  endfacet', file=fp)
  
}




### Start year  
# i <- 1
 for (i in 1:Max_age)  { 
  y <- as.numeric(Pop$Year[1])
  z <- as.numeric(Pop$Age[i])

  
  mx <-                              -as.numeric(Pop$Males  [i]   )
  mxx <-  ifelse( z >= Max_age-1,0,  -as.numeric(Pop$Males  [i+1]))   ## pop at age i+1 , year i+1
  fx <-                               as.numeric(Pop$Females[i]   )
  fxx <-  ifelse( z >= Max_age-1,0,   as.numeric(Pop$Females[i+1]))   ## pop at age i+1 , year i+1
  


  ## Triangle A
  
  write(sprintf('  facet normal %f %f %f', 0, y-100, z+.2), file=fp)
  write('    outer loop', file=fp)
  write(sprintf('      vertex %f %f %f', mx  , y  , z   ) , file=fp)
  write(sprintf('      vertex %f %f %f', fx  , y  , z   ) , file=fp)
  write(sprintf('      vertex %f %f %f', fxx , y,  z +1 ) , file=fp)
  write('    endloop', file=fp)
  write('  endfacet', file=fp)
  
  
  ## Triangle B
  write(sprintf('  facet normal %f %f %f', 0, y-1, z+.8 ) , file=fp)
  write('    outer loop', file=fp)
  write(sprintf('      vertex %f %f %f', fxx  , y  , z+1  ) , file=fp)
  write(sprintf('      vertex %f %f %f', mxx  , y  , z+1  ) , file=fp)
  write(sprintf('      vertex %f %f %f', mx   , y  , z    ) , file=fp)
  write('    endloop', file=fp)
  write('  endfacet', file=fp)
  
}


### End year  
End <- subset(Pop, Year == Max_year )

for (i in 1:Max_age) { 
  y <- as.numeric(Max_year)
  z <- as.numeric(Pop$Age[i])
  
  
  mx <-                              -as.numeric(End$Males  [i]   )
  mxx <-  ifelse( z >= Max_age-1,0,  -as.numeric(End$Males  [i+1]))   ## pop at age i+1 , year i+1
  fx <-                               as.numeric(End$Females[i]   )
  fxx <-  ifelse( z >= Max_age-1,0,   as.numeric(End$Females[i+1]))   ## pop at age i+1 , year i+1
  
  
  
  ## Triangle A
  
  write(sprintf('  facet normal %f %f %f', 0, y+1, z+.2), file=fp)
  write('    outer loop', file=fp)
  write(sprintf('      vertex %f %f %f', mx  , y  , z   ) , file=fp)
  write(sprintf('      vertex %f %f %f', fxx , y,  z +1 ) , file=fp)
  write(sprintf('      vertex %f %f %f', fx  , y  , z   ) , file=fp)
  write('    endloop', file=fp)
  write('  endfacet', file=fp)
  
  
  ## Triangle B
  write(sprintf('  facet normal %f %f %f', 0, y+1, z+.8 ) , file=fp)
  write('    outer loop', file=fp)
  write(sprintf('      vertex %f %f %f', fxx  , y  , z+1  ) , file=fp)
  write(sprintf('      vertex %f %f %f', mx   , y  , z    ) , file=fp)
  write(sprintf('      vertex %f %f %f', mxx  , y  , z+1  ) , file=fp)
  write('    endloop', file=fp)
  write('  endfacet', file=fp)
  
}



### Bottom / Births  
Births <- subset(Pop, Age == 0 )


for (i in 1:No_years) { 
  y <- as.numeric(Births$Year[i])
  z <- 0
  
  
  mx <-                              -as.numeric(Births$Males  [i]   )
  mxx <-  ifelse( z >= Max_age-1,0,  -as.numeric(Births$Males  [i+1]))   ## pop at age i+1 , year i+1
  fx <-                               as.numeric(Births$Females[i]   )
  fxx <-  ifelse( z >= Max_age-1,0,   as.numeric(Births$Females[i+1]))   ## pop at age i+1 , year i+1
  
  
  
  ## Triangle A
  
  write(sprintf('  facet normal %f %f %f', 0, y+.2, z-1), file=fp)
    write('    outer loop', file=fp)
      write(sprintf('      vertex %f %f %f', mx   , y    , z   ) , file=fp)
      write(sprintf('      vertex %f %f %f', mxx  , y+1  , z   ) , file=fp)
      write(sprintf('      vertex %f %f %f', fxx  , y+1  , z   ) , file=fp)
    write('    endloop', file=fp)
  write('  endfacet', file=fp)
  
  
  ## Triangle B
  write(sprintf('  facet normal %f %f %f', 0, y+.8, z-1 ) , file=fp)
  write('    outer loop', file=fp)
  write(sprintf('      vertex %f %f %f', fxx  , y+1  , z  ) , file=fp)
  write(sprintf('      vertex %f %f %f', fx   , y    , z  ) , file=fp)
  write(sprintf('      vertex %f %f %f', mx   , y    , z  ) , file=fp)
  write('    endloop', file=fp)
  write('  endfacet', file=fp)
  
}



write('endsolid pyramid', file=fp)


##  temp_version <- read.csv("c:/users/Tim.Carlton/downloads/Italy.stl")      ## These steps help if I am debugging, and want to create a txt file as well as an stl file.
##  write.csv(temp_version, "c:/users/Tim.Carlton/downloads/Population.txt")   


print(paste("1 mm = 1 year of age, 1 year of time, and ",choice$Scale," people"))
print(paste("Structure is ",Max_age-Min_age,"mm by ", Max_year-Min_year," mm by "
            ,as.integer(max (Pop$Males)-min(Pop$Females)),"mm"))
print("stretch or contract this in your 3D printer")
print("Viewstl.com is really cool way of checking")
print(filename)

